<?php
include 'header.php';
include 'include/function.php';

						if(isset($_POST['client']))
						{
						echo "client is working";
						// print_r($_POST);
									 $client_id=$_POST['client_id'];
									 $name=$_POST['name'];
									 $p_amount=$_POST['p_amount'];
									 $interest_rate=$_POST['interest_rate'];
									 $installment=$_POST['installment'];
									 $period=$_POST['period'];
									 $filecharge=$_POST['filecharge'];
									 $rule=$_POST['rule'];
									 $start_month=$_POST['start_month'];
									 $total_payable=$_POST['total_payable'];
									 $status=$_POST['status'];
									 $sql="UPDATE `client` SET `client_id`='$client_id',`name`='$name',`p_amount`='$p_amount',`interest_rate`='$interest_rate',`installment`='$installment',`period`='$period',`filecharge`='$filecharge',`rule`='$rule',`start_month`='$start_month',`total_payable`='$total_payable',`status`='$status' WHERE `client_id`='$client_id'";
									 update_dynamic($sql);
									 
						}
						else if(isset($_POST['payment_state']))
						{
						
								// foreach ($_POST as $key => $value) {
								  // echo '<p>'.$key.'</p>';
								  // foreach($value as $k => $v)
								  // {
								  // echo '<p>'.$k.'</p>';
								  // echo '<p>'.$v.'</p>';
								  // echo '<hr />';
								  // }
								// }
								
								
											$payment_id=$_POST['payment_id'];
											$client_id=$_POST['client_id'];
											$date=$_POST['date'];
											$deposit=$_POST['deposit'];
											// $payment_state=$_POST['payment'];
											
											// UPDATE `payment_state` SET `payment_id`=[value-1],`client_id`=[value-2],`date`=[value-3],`deposit`=[value-4] WHERE 1
											$sql="UPDATE `payment_state` SET `payment_id`='$payment_id',`client_id`='$client_id',`date`='$date',`deposit`='$deposit' WHERE `payment_id`='$payment_id'";
									 update_dynamic($sql);
						}
						else if(isset($_POST['installment_state']))
						{
						echo "Installment is working";
								  // foreach ($_POST as $key => $value) {
								  // echo '<p>'.$key.'</p>';
								  // foreach($value as $k => $v)
								  // {
								  // echo '<p>'.$k.'</p>';
								  // echo '<p>'.$v.'</p>';
								  // echo '<hr />';
								  // }
								  // }
										$Installment_id=$_POST['Installment_id'];
										$client_id=$_POST['client_id'];
										$date=$_POST['date'];
										$deposit=$_POST['deposit'];
										$installment=$_POST['installment'];
										$status=$_POST['status'];
										
										$sql="UPDATE `installment_state` SET `Installment_id`='$Installment_id',`client_id`='$client_id',`date`='$date',`deposit`='$deposit',`installment`='$installment',`status`='$status' WHERE `Installment_id`='$Installment_id'";
										update_dynamic($sql);
						}
						else if(isset($_POST['interest_state']))
						{
						echo "Interest is working";
								  // foreach ($_POST as $key => $value) {
								  // echo '<p>'.$key.'</p>';
								  // foreach($value as $k => $v)
								  // {
								  // echo '<p>'.$k.'</p>';
								  // echo '<p>'.$v.'</p>';
								  // echo '<hr />';
								  // }
								  // }
								  
								$interest_id=$_POST['interest_id'];
								$client_id=$_POST['client_id'];
								$date=$_POST['date'];
								$interest=$_POST['interest'];
								
								$sql="UPDATE `interest_state` SET `interest_id`='$interest_id',`client_id`='$client_id',`date`='$date',`interest`='$interest' WHERE `interest_id`='$interest_id'";
										update_dynamic($sql);
								
						}
						
						
						
						

?>