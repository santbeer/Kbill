<?php
include 'include/function1.php';
include "configuration.php";

if(isset($_POST['login']))
	{
		// echo "running";
		// print_r($_POST);
		$user=$_POST['user'];
		$pass=$_POST['pass'];
		// echo $user."<br>".$pass;
				if(validate_user($user,$pass))
				{
				 echo "logged in";
				 // $user->redirect('index.php');
				 echo $_SESSION['user_name'];
				 
				header("Location: index.php"); /* Redirect browser */
				exit();
				}
				else{
					echo "failed";
				}
					
		
	}


?>