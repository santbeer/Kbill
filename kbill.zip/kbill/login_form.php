<div class="container">
     <div class="form-container">
        <form method="post" action='validate.php'>
            <h2>Sign In</h2><hr />
            
            <div class="form-group">
            <input type="text" class="form-control" name="user" placeholder="Enter Username" value="" required />
            </div>
           
            <div class="form-group">
             <input type="password" class="form-control" name="pass" placeholder="Enter Password" required />
            </div>
            <div class="clearfix"></div><hr />
            <div class="form-group">
             <button type="submit" class="btn btn-block btn-primary" name="login">
                 <i class="glyphicon glyphicon-log-in"></i>&nbsp;&nbsp;SIGN IN
                </button>
            </div>
            
        </form>
       </div>
</div>