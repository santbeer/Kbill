<?php 
include 'header.php';
include 'include/function.php';

$status='All';
echo"<nav class='navbar navbar-default' >
			  <div class='container-fluid'>
			  <form class='navbar-form navbar-right' action='' method='post'>
			 
			 
			 	<div class='form-group'><div style='background:#00b3b3; padding:5px; border-radius:5px 5px 5px 5px; '>
				<select name='status1' class='form-control' id='sel1'>
				<option value='All'>All</option>
				<option value='Active'>Active</option>
				<option value='Closed'>Closed</option>
				</select >
				<button type='submit' name='show_all' data-toggle='tooltip' title='Search' class='btn btn-default'><span class='glyphicon glyphicon-search'>  </button>
			  </div></div>
			  
			  
			  <div data-toggle='tooltip' title='Enter Starting Date and Ending Date' class='form-group'><div style='background:#00b3b3; padding:5px; border-radius:5px 5px 5px 5px; '>
				<select name='status' class='form-control' id='sel1'>
				<option value='All'>All</option>
				<option value='Active'>Active</option>
				<option value='Closed'>Closed</option>
				</select>
				<input type='date'  name='date_from' class='form-control'>
				<input type='date' name='date_to' class='form-control'>
				<button type='submit' name='by_date_range' class='btn btn-default'><span class='glyphicon glyphicon-search'>  </button>
			  </div></div>
			  
			  
			  <div class='form-group'><div style='background:#00b3b3; padding:5px; border-radius:5px 5px 5px 5px; '>
				<input type='text' name='Payment_id' class='form-control' placeholder='Payment ID'>
				<button type='submit' name='by_payment_id' data-toggle='tooltip' title='Transaction ID' class='btn btn-default'><span class='glyphicon glyphicon-search'>  </button>
			  </div></div>

			  
			  <div class='form-group'><div style='background:#00b3b3; padding:5px; border-radius:5px 5px 5px 5px; '>
				<input type='text' name='client_id' class='form-control' placeholder='Search Customer ID'>
				<button type='submit' name='by_customer_id' data-toggle='tooltip' title='Search by ID' class='btn btn-default'><span class='glyphicon glyphicon-search'>  </button>
			  </div></div>
			  
			  
			  
			  
			</form>
			  
			  </div>
			  </nav>";
			  
			  if(isset($_POST['by_date_range']))	
							{
								if($_POST['date_from']==null or $_POST['date_to']==null )
								{
									die("<div class='error'><div class='alert alert-warning alert-dismissable'><strong>Warning!</strong> Must Choose Date Range </div></div>");
								}
							$sql="SELECT * FROM `payment_state` WHERE `date` BETWEEN '".$_POST['date_from']."' AND '".$_POST['date_to']."'";
							// $sql="SELECT * FROM `payment_state` WHERE `client_id`='".$_POST['d_from']."'";
							$status=$_POST['status'];
							}
							else if(isset($_POST['by_customer_id']))
							{
								if($_POST['client_id']==null)
								{
									die("<div class='error'><div class='alert alert-warning alert-dismissable'><strong>Warning!</strong> Must enter valid customer id </div></div>");
								}
								$sql="SELECT * FROM `payment_state` WHERE `client_id`='".$_POST['client_id']."'";
							}
							else if(isset($_POST['by_payment_id']))
							{
								if($_POST['by_payment_id']==null)
								{
									die("<div class='error'><div class='alert alert-warning alert-dismissable'><strong>Warning!</strong> Must enter valid Payment id </div></div>");
								}
								$sql="SELECT * FROM `payment_state` WHERE `payment_id`='".$_POST['Payment_id']."'";
							}
							else if(isset($_POST['show_all']))
							{
								$status=$_POST['status1'];
								$sql="SELECT * FROM `payment_state` WHERE 1";
							}
							else
							{
								$sql="SELECT * FROM `payment_state` WHERE 1";
							}

//$sql = "SELECT * FROM `payment_state` WHERE 1";
echo "<div class='panel panel-default'>
	  <div class='panel-heading'><strong>Payment List</strong></div>
			<div class='panel-body'>";
			
view_payment($sql,$status);

echo "</div></div>";


?>

<?php

include 'footer.php';
?>

