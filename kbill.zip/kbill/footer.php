

</div>
<footer class="active">
<table>

<table class="table">
<tr>
<td>
Copyright <?php echo date("Y"); ?> reserved by <?php echo COMPANY; ?>
</td>
<td>
</td>
<td>
</td>
<td>
Powered By <?php echo " <a href='".DEVELOPER_LINK."' target=_blank>".DEVELOPER_NAME."</a>"; ?> 
</td>
</tr>	  
</table>	  
</footer>
</body>
</html>