<?php 
include 'header.php';
include 'include/function.php';


	// print_r($_GET);
	$id='';
		// echo $_GET['id'];
		if($_GET['id']=='' or $_GET['id']==null)
		{
			// echo "Could not process request with null parameter";
			die("<div class='error'><div class='alert alert-warning alert-dismissable'><strong>Sorry!</strong> Could not process request with NULL parameter </div></div>");
		}
		else
		{
			$id=$_GET['id'];
			$sql="DELETE FROM `client` WHERE `client_id`='$id'";
		}

// reset($_POST);
// while (list($key, $val) = each($_POST)) {
    // echo "$key => $val\n";
	// echo "$key \n";
// }

//die($sql);

	 data_delete($sql);


?>

  
	
	
	<br>
  <a href="#" class="btn btn-default btn-sm">
	<span class="glyphicon glyphicon-arrow-up"></span> Up
  </a>
  <br>

  
 



<?php

include 'footer.php';
?>