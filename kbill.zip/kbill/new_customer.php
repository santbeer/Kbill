<?php 
include 'header.php';
include 'include/function.php';




if(isset($_POST['new_customer']))
{
		$c_name=$_POST['c_name'];
		$p_amount=$_POST['p_amount'];
		$i_rate=$_POST['i_rate'];
		$M_instal=$_POST['M_instal'];
		$Period=$_POST['Period'];
		$f_charge=$_POST['f_charge'];
		$rule_id=$_POST['type'];
		$s_date=$_POST['s_date'];
		$t_pay=$_POST['t_pay'];
		$status=$_POST['status'];
	
	
	
	$sql ="INSERT INTO `client`(`name`, `p_amount`, `interest_rate`, `installment`, `period`, `filecharge`, `rule`, `start_month`, `total_payable`, `status`) VALUES ('$c_name','$p_amount','$i_rate','$M_instal','$Period','$f_charge','$rule_id','$s_date','$t_pay','$status')";
	insert_customer($sql);
}

?>

  <div id="new_customer" class="container-fluid">
  <h4>Add New Customer</h4>
  <p>This is Customer Registration form</p>
  
  <form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post">
  <div class="input-group">
      <span class="input-group-addon">Customer Name</span>
      <input id="c_name" name="c_name" type="text" class="form-control"   required >
  </div>
  <br>
  <div class="input-group">
      <span class="input-group-addon">Principle Amount</span>
      <input id="p_amount" name="p_amount" type="text" class="form-control"   onchange="calc()" required >
  </div>
  <br>
  <div class="input-group">
      <span class="input-group-addon">Interest Rate</span>
      <input id="i_rate" name="i_rate" type="text" class="form-control"   onchange="calc()" required >
  </div>
  <br>
  <div class="input-group">
      <span class="input-group-addon">Monthly Installment</span>
      <input id="M_instal" name="M_instal" type="text" class="form-control"    required >
  </div>
  <br>
  <div class="input-group">
      <span class="input-group-addon">Period/Duration</span>
      <input id="Period" name="Period" type="text" class="form-control"   onchange="calc()"  required >
  </div>
  <br>
  <div class="input-group">
      <span class="input-group-addon">File Charge</span>
      <input id="f_charge" name="f_charge" type="text" class="form-control"   onchange="calc()" required >
  </div>
  <br>
  <div class="input-group">
      <span class="input-group-addon">Start From</span>
      <input id="s_date" name="s_date" type="date" class="form-control"    required >
  </div>
  <br>
  <div class="input-group">
      <span class="input-group-addon">Total Payable</span>
      <input id="t_pay" name="t_pay" type="text" class="form-control"    required >
  </div>
  <br>
  <div class="input-group">
      <span class="input-group-addon">Type</span>
        <select id="type" name="type" class="form-control" disabled onchange="calc()">
		
		<option Value="Fix">Fix</option>
		<option value="Flexi">Flexi</option>
		</select>
		<input id="t_pay" name="form_t" type="hidden" class="form-control" value="new_customer"    required >
  </div>
  <br>
  <div class="input-group">
      <span class="input-group-addon">Type</span>
        <select id="status" name="status" class="form-control" onchange="calc()">
		<option value="Active">Active</option>
		<option Value="Closed">Closed</option>
		</select>
		<input id="t_pay" name="form_t" type="hidden" class="form-control" value="new_customer"    required >
  </div>
  
  <br>
  <button type="submit" name="new_customer" class="btn btn-default">Submit</button>
</form>

  </div>


  
	
	
	<br>
  <a href="#" class="btn btn-default btn-sm">
	<span class="glyphicon glyphicon-arrow-up"></span> Up
  </a>
  <br>

  
  <script>
  function calc(){
	  
	  var file_charge=0;
      var p_amount = document.getElementById('p_amount').value;
      var i_rate = document.getElementById('i_rate').value;
	  
	  
	  var e = document.getElementById("type");
	  var flex_or_fix = e.options[e.selectedIndex].value;


	  //var flex_or_fix = type.value;
	  var file_charge = document.getElementById('f_charge').value;
	  
	  var period = document.getElementById('Period').value;
	  
	  //alert(flex_or_fix);
	  // var p_amount =5;
      // var i_rate = 5;
	  
	  // var period = 5;
	  
	  //var t_pay = (p_amount/100)*i_rate;
	  
	  
	  var t_pay = (p_amount/100)*i_rate;
	  
	  var t_pay = parseInt((t_pay*period));
	  
	  //IF not FLEXI THEN ADD UP ALL INTEREST FOR WHOLE PERIOD
	  if(flex_or_fix=='Fix')
	  {
	  var t_pay = parseInt(t_pay)+parseInt(p_amount);
	  }
	  else
	  {
		  var t_pay=parseInt(p_amount);
	  }
	  
	  var t_pay = parseInt(file_charge)+parseInt(t_pay);
	  //alert(flex_or_fix);
	  
	  document.getElementById("t_pay").value = t_pay;
	  
	  document.getElementById("M_instal").value = t_pay/period;
	  
      //alert(user.value);
      //alert(pass.value);
  }
</script>



<?php

include 'footer.php';
?>