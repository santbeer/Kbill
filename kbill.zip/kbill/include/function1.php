<?php
//include "validate.php";

// ****************************************************************
// THIS METHOD IS USED PRINT TOTAL INTEREST OF CUSTOMER
	function TOTAL_INTEREST_BY_CID($id)
	{
		
		try 
		{
		$conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE."", DB_USER, DB_PASSWORD);    
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql1 = "SELECT * FROM `interest_state` WHERE `client_id`='$id' ";
		
		$stmt = $conn->query($sql1);
		$stmt1 = $conn->query($sql1);
		$stmt->setFetchMode(PDO::FETCH_ASSOC);

						
						
						
		
		
			
					$t_interest=0;
			
					if ($stmt1->rowCount() > 0)
					{		
								while($row1 = $stmt1->fetch()) 
								{
									
									
									$t_interest=$row1['interest']+$t_interest;													
									
									
								}	
								return $t_interest; 
					}
					else					
					{
						
					
					return 0;
					}
							
			
				
		}
		catch(PDOException $e)
		{
		echo $sql . "<br>" . $e->getMessage();
		}
		$conn = null;
	}

	
	// ****************************************************************
// THIS METHOD IS USED PRINT TOTAL PAYMENT RECEIVED FROM CUSTOMER
	function TOTAL_PAYMENT_BY_CID($id)
	{
		
		try 
		{
		$conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE."", DB_USER, DB_PASSWORD);    
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql1 = "SELECT * FROM `payment_state` WHERE `client_id`='$id' ";
		
		$stmt = $conn->query($sql1);
		$stmt1 = $conn->query($sql1);
		$stmt->setFetchMode(PDO::FETCH_ASSOC);

						
						
						
		
		
			
					
					$t_deposit=0;
					$row=0;
					if ($stmt1->rowCount() > 0)
					{		
								while($row1 = $stmt1->fetch()) 
								{
									
									$row=$row+1;
									$t_deposit=$row1['deposit']+$t_deposit;													
									
									
								}	
								// return $t_deposit;
								// return $row;
								return array($t_deposit,$row);
								
					}
					else					
					{
						
					
					return 0;
					}
							
			
				
		}
		catch(PDOException $e)
		{
		echo $sql . "<br>" . $e->getMessage();
		}
		$conn = null;
	}

	
	function EDIT_ALL($sql,$tbname)
	{

		$sql1=$sql;

		// echo $status; 
		
		try 
		{
		$conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE."", DB_USER, DB_PASSWORD);    
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		
				
		$stmt = $conn->query($sql1);
		$stmt1 = $conn->query($sql1);
		$stmt->setFetchMode(PDO::FETCH_ASSOC);

		$col_name=array();
		
					$row = $stmt->fetch();
					reset($row);
						
						echo "<div  class='container-fluid'>";
						echo "<form action='update_all.php' method='post'>";
											
						while(list($key, $val) = each($row) ) 
						{
							
							 $str=strtoupper($key);
							$str=str_replace("_"," ",$str);
							// echo "<tr>";
							// echo "<td>".$str."</td><td>".$val."</td>";
							// echo "</tr>";
							
							
							// echo " <div class='form-group'><span class='input-group-addon'>".$key."</span>
				// <input type='text' name='".$key."' class='form-control' placeholder='".$str."' value='".$val."' ></div><br>";
				
				
					echo "<div class='input-group'> <span class='input-group-addon'>".$str."</span>
					<input id='i_rate' name='".$key."' type='text' value='".$val."' class='form-control'   required >
					</div><br>";
						
						}
						
						echo "<button type='submit' name='".$tbname."' data-toggle='tooltip'  class='btn btn-default'><span class='glyphicon glyphicon-search'> Update</button>
			  </div>";
					
					echo "</form>";
					echo "</div>";
					
					
						
				
				
		}
		catch(PDOException $e)
		{
		echo $sql . "<br>" . $e->getMessage();
		}
		$conn = null;	
}


	function validate_user1($user,$pass)
	{
		//echo $sql;
		
		try 
		{
		session_start();
		
		$conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE."", DB_USER, DB_PASSWORD);    
		// $stmt = $this->db->prepare("SELECT * FROM user WHERE user=:uname and pass=:pass LIMIT 1");
		$stmt = $conn->prepare("SELECT * FROM user WHERE user=:uname and pass=:pass LIMIT 1");
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		
		$pass=md5($pass);
		$stmt->execute(array(':uname'=>$user, ':pass'=>$pass));
		
		$userRow=$stmt->fetch(PDO::FETCH_ASSOC);
          if($stmt->rowCount() > 0)
          {
			  
			$_SESSION['user_id'] = $userRow['user_id'];  
			$_SESSION['user_name'] = $userRow['user'];  
			return true;
		  }
		  else
		  {
			  // echo "I am here";
			 return false;
		  }
			
				
		}
		catch(PDOException $e)
		{
		echo $sql . "<br>" . $e->getMessage();
		}
		$conn = null;
	}
	
	
	
	function validate_user($user,$pass)
	{
		
		
		session_start();
		try 
		{
		$conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE."", DB_USER, DB_PASSWORD);    
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$pass=md5($pass);
		$sql = "SELECT * FROM `user` WHERE `user`='$user' and `pass`='$pass'";		
		$stmt = $conn->query($sql);
		$row=$stmt->setFetchMode(PDO::FETCH_ASSOC);
			if ($stmt->rowCount() > 0)
			{
				$user_id='';
				$user1='';
				while($row = $stmt->fetch())
				{
				$user_id=$row['user_id'];
				$user1=$row['user'];				
				}
				$_SESSION['user_id'] = $user_id;;  
				$_SESSION['user_name'] = $user1;
				return true;
			}
			else
			{
				return false;
			}	
		}
		catch(PDOException $e)
		{
		echo $sql . "<br>" . $e->getMessage();
		}
		$conn = null;
	}

	function SESSION_CHECK()
	{
					session_start();

					if(!isset($_SESSION['user_name']))
					{
					   
						header("Location: logout.php");
					}
					else
					{
						echo "Welcome ".$_SESSION['user_name'];
					}
	}


	?>