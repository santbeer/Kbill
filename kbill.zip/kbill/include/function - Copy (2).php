<?php
//include "validate.php";
	function insert_customer($sql)
	{			
		$sql1 = $sql; 
		try 
		{
		$conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE."", DB_USER, DB_PASSWORD);    
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);  
		$conn->exec($sql1);
		$last_id = $conn->lastInsertId();
		
		echo "
		<div class='alert alert-success alert-dismissable'>
		<a href='#' class='close' data-dismiss='alert' aria-label='close'>×</a>
		<strong>Success!</strong> New Customer Added successfully. Account Number is = <span class='badge'>".$last_id."</span>
		</div>
			 ";
		}
		catch(PDOException $e)
		{
		echo $sql . "<br>" . $e->getMessage();
		}
		$conn = null;	
	}
 	
	
// ****************************************************************
// THIS METHOD IS USED TO FETCH RECORD FROM CUSTOMER TABLE IN DATABASE 		  
  	function view_customer($sql)
	{
		$sql1=$sql;
		try 
		{
		$conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE."", DB_USER, DB_PASSWORD);    
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		//$sql1 = "SELECT * FROM `client` WHERE 1";
				
		$stmt = $conn->query($sql1);
		$stmt1 = $conn->query($sql1);
		$stmt->setFetchMode(PDO::FETCH_ASSOC);

		$col_name=array();
		
					$row = $stmt->fetch();
					reset($row);
						echo"<div class='table-responsive'>";
						echo "<table class='table table-striped table-bordered table-hover table-condensed'>";
						echo "<thead><tr>";			
					while(list($key, $val) = each($row) ) {
					
						$str=strtoupper($key);
						$str=str_replace("_"," ",$str);
						
						echo "<th>".$str."</th>";
						
						
						
					$col_name[]=$key;
					}
					echo "<th>E</th>";
					echo "<th>D</th>";
					echo "<th>V</th>";
						echo "</tr>";
		// print_r($col_name);
		
			$t_payment=0;
			
			
			while($row1 = $stmt1->fetch()) 
			{
				echo "<tr>";
				echo "<td>".$row1['client_id']."</td>";
				echo "<td>".$row1['name']."</td>";
				echo "<td>".$row1['p_amount']."</td>";
				$t_payment=$t_payment+$row1['p_amount'];
				echo "<td>".$row1['interest_rate']."</td>";
				echo "<td>".$row1['installment']."</td>";
				echo "<td>".$row1['period']."</td>";
				echo "<td>".$row1['filecharge']."</td>";
				echo "<td>".$row1['rule']."</td>";				
				
				// echo "<td>".get_rule_name($row1['rule_id'])."</td>";
				
				echo "<td>".$row1['start_month']."</td>";
				echo "<td>".$row1['total_payable']."</td>";
				echo "<td>".$row1['status']."</td>";
				echo "<td><a href='edit_all.php?id=".$row1['client_id']."&act=customer' data-toggle='tooltip' title='Edit'><span class='glyphicon glyphicon-edit'></span> </a></td>";
				echo "<td><a href='del_customer.php?id=".$row1['client_id']."' data-toggle='tooltip' title='Delete' onclick=\"return confirm(' Sure!! you want to delete?');\" ><span class='glyphicon glyphicon-trash red'></span> </a></td>";
				echo "<td><a href='view_all.php?id=".$row1['client_id']."&act=customer' data-toggle='tooltip' title='View'><span class='	glyphicon glyphicon-eye-open'></span> </a></td>";
				
				
				 
				echo "</tr>";
			}	
			echo "<div class='row'><div class='col-sm-1' style='margin-left:20px; padding:3px; background:#009696; color:white;'><strong> Total In Market:</strong></div>  <div class='col-sm-1' style=' padding:3px; background:#00C2C2; color:white;'>".CURRENCY." {$t_payment}</div></div>";
				
			echo "</table></div>";
				
		}
		catch(PDOException $e)
		{
		echo $sql . "<br>" . $e->getMessage();
		}
		$conn = null;
	}
	
// ****************************************************************
// THIS METHOD IS USED TO INSERT RECORD IN INSTALLMENT TABLE IN DATABASE 
	function insert_installment($sql)
	{	
		//echo $sql."<br>";	
		try 
		{
		$conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE."", DB_USER, DB_PASSWORD);    
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql1 = $sql;    
		$conn->exec($sql1);
		$last_id = $conn->lastInsertId();
		//echo "New record created successfully. Account Number is = ".$last_id;
		echo "
		<div class='alert alert-success alert-dismissable'>
		<a href='#' class='close' data-dismiss='alert' aria-label='close'>×</a>
		<strong>Success!</strong> New Installment Added successfully. Installment Number is = <span class='badge'>".$last_id."</span>
		</div>
			 ";
		}
		catch(PDOException $e)
		{
		echo $sql . "<br>" . $e->getMessage();
		}
		$conn = null;	
	}

// ****************************************************************
// THIS METHOD IS USED TO INSERT RECORD IN PAYMENT TABLE IN DATABASE
	function insert_payment($sql)
	{	
		//echo $sql."<br>";	
		try 
		{
		$conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE."", DB_USER, DB_PASSWORD);    
		$sql1 = $sql;    
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$conn->exec($sql1);
		$last_id = $conn->lastInsertId();
		//echo "New record created successfully. Account Number is = ".$last_id;
		echo "
		<div class='alert alert-success alert-dismissable'>
		<a href='#' class='close' data-dismiss='alert' aria-label='close'>×</a>
		<strong>Success!</strong> New Payment Added successfully. Transaction ID is = <span class='badge'>".$last_id."</span>
		</div>
			 ";
		}
		catch(PDOException $e)
		{
		echo $sql . "<br>" . $e->getMessage();
		}
		$conn = null;	
	}
// ****************************************************************
// THIS METHOD IS USED TO FETCH RECORD FROM PAYMENT TABLE IN DATABASE
	function get_rule_name($rule_id)
	{

		$rule_id1=$rule_id;
		
		try 
		{
		$conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE."", DB_USER, DB_PASSWORD);    
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql1 = "SELECT `name` FROM `rules` WHERE `type`='".$rule_id1."'";
		// echo $sql1;		
		$stmt = $conn->query($sql1);
		
		$stmt->setFetchMode(PDO::FETCH_ASSOC);
		
			while($row = $stmt->fetch()) 
			{
				
				// echo "<td>".$row['name']."</td>";
				return $row['name'];
				
			}	
			
				
			
				
		}
		catch(PDOException $e)
		{
		echo $sql . "<br>" . $e->getMessage();
		}
		$conn = null;	
}

	function view_payment($sql,$status)
	{

		$sql1=$sql;
		$status=$status;
		// echo $status; 
		
		try 
		{
		$conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE."", DB_USER, DB_PASSWORD);    
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		//$sql1 = "SELECT * FROM `payment_state` WHERE 1";
				
		$stmt = $conn->query($sql1);
		$stmt1 = $conn->query($sql1);
		$stmt->setFetchMode(PDO::FETCH_ASSOC);

		$col_name=array();
		
					$row = $stmt->fetch();
					reset($row);
						echo"<div class='table-responsive'>";
						echo "<table class='table table-striped table-bordered table-hover table-condensed'>";
						echo "<thead><tr>";			
					while(list($key, $val) = each($row) ) {
						$str=strtoupper($key);
						$str=str_replace("_"," ",$str);
						
						echo "<th>".$str."</th>";
					$col_name[]=$key;
					}
					
					echo "<th>E</th>";
					echo "<th>D</th>";
					echo "<th>V</th>";
						echo "</tr>";
		// print_r($col_name);
			
			$t_payment='0';
			// echo "status: ".$status."<br>";
			// echo check_status_id(8);
			// die();
			// if(check_status_id($row1['client_id'])==$status)
			// {
				
			// }
			
			while($row1 = $stmt1->fetch()) 
			{
				
				// if(check_status_id($row1['client_id'])==$status)
					//echo $row1['client_id'];
						// echo check_status_id($row1['client_id']);
						// die();
					
					// if(check_status_id($row1['client_id'])==$status OR $status=="All")
					if(check_status_id($row1['client_id'])==$status OR $status=="All")	
					{
						// echo $status;
						// echo check_status_id($row1['client_id']);
					echo "<tr>";
					echo "<td>".$row1['payment_id']."</td>";
					echo "<td>".$row1['client_id']."</td>";
					echo "<td>".$row1['date']."</td>";
					echo "<td> ".$row1['deposit']."</td>";
					$t_payment=$t_payment+$row1['deposit'];	
					echo "<td><a href='edit_all.php?id=".$row1['payment_id']."&act=payment' data-toggle='tooltip' title='Edit'><span class='glyphicon glyphicon-edit'></span> </a></td>";					
					echo "<td><a href='del_payment.php?id=".$row1['payment_id']."' data-toggle='tooltip' title='Delete' onclick=\"return confirm(' Sure!! you want to delete?');\" ><span class='glyphicon glyphicon-trash red'></span> </a></td>";
					echo "<td><a href='view_all.php?id=".$row1['payment_id']."&act=payment' data-toggle='tooltip' title='View'><span class='	glyphicon glyphicon-eye-open'></span> </a></td>";
					echo "</tr>";
					}
					else
					{}
			}	
			
			// echo "<div class='row'><div class='col-sm-1' style='margin-left:20px; padding:3px; background:#009696; color:white;'><strong> Total In Market:</strong></div>  <div class='col-sm-1' style=' padding:3px; background:#00C2C2; color:white;'>".CURRENCY." {$t_payment}</div></div>";
			
			echo "<tr ><td style='background:#009696; color:white;' ><strong>Total Payments :</strong></td><td style='background:#00C2C2; color:white;'><strong>".CURRENCY." ".$t_payment."</strong></td></tr>";
			echo"</table></div>";
				
			
				
		}
		catch(PDOException $e)
		{
		echo $sql . "<br>" . $e->getMessage();
		}
		$conn = null;	
}


	function check_status_id($client_id)
	{
		
		$client_id=$client_id;
		
		try 
		{
		$conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE."", DB_USER, DB_PASSWORD);    
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		// $sql1 = "SELECT `name` FROM `client` WHERE `type`='".$rule_id1."'";
		$sql = "SELECT * FROM `client` WHERE `client_id`='".$client_id."'";
		// echo $sql1;		
		$stmt = $conn->query($sql);
		
		$stmt->setFetchMode(PDO::FETCH_ASSOC);
		
			while($row = $stmt->fetch()) 
			{
				
				// echo "<td>".$row['name']."</td>";
				//echo $row['status'];
				return $row['status'];
				
			}	
			
				
			
				
		}
		catch(PDOException $e)
		{
		echo $sql . "<br>" . $e->getMessage();
		}
		$conn = null;
	}

// ****************************************************************
// THIS METHOD IS USED TO FETCH RECORD FROM INSTALLMENT TABLE IN DATABASE	
function view_installment($sql,$status)
	{
		$sql1=$sql;
		
		try 
		{
		$conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE."", DB_USER, DB_PASSWORD);    
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		// $sql1 = "SELECT * FROM `installment_state` WHERE 1";
				
		$stmt = $conn->query($sql1);
		$stmt1 = $conn->query($sql1);
		$stmt->setFetchMode(PDO::FETCH_ASSOC);

		$col_name=array();
		
					$row = $stmt->fetch();
					reset($row);
						echo"<div class='table-responsive'>";
						echo "<table class='table table-striped table-bordered table-hover table-condensed'>";
						echo "<thead><tr>";			
					while(list($key, $val) = each($row) ) {
						
						$str=strtoupper($key);
						$str=str_replace("_"," ",$str);
						echo "<th>".$str."</th>";					
					
						$col_name[]=$key;
					}
					
					echo "<th>E</th>";
					echo "<th>D</th>";
					echo "<th>V</th>";
						echo "</tr>";
		// print_r($col_name);
			
			$t_payment='0';
			
			while($row1 = $stmt1->fetch()) 
			{
				if(check_status_id($row1['client_id'])==$status OR $status=="All")	
				{
				echo "<tr>";
				echo "<td>".$row1['Installment_id']."</td>";
				echo "<td>".$row1['client_id']."</td>";
				echo "<td>".$row1['date']."</td>";
				echo "<td>".$row1['deposit']."</td>";
				echo "<td>".$row1['installment']."</td>";
				$t_payment=$t_payment+$row1['installment'];	
				echo "<td>".$row1['status']."</td>";
				
				echo "<td><a href='edit_all.php?id=".$row1['Installment_id']."&act=installment' data-toggle='tooltip' title='Edit'><span class='glyphicon glyphicon-edit'></span> </a></td>";
				echo "<td><a href='del_installment.php?id=".$row1['Installment_id']."' data-toggle='tooltip' title='Delete' onclick=\"return confirm(' Sure!! you want to delete?');\" ><span class='glyphicon glyphicon-trash red'></span> </a></td>";
				echo "<td><a href='view_all.php?id=".$row1['Installment_id']."&act=installment' data-toggle='tooltip' title='View'><span class='	glyphicon glyphicon-eye-open'></span> </a></td>";
				echo "</tr>";
				}
			}	
			
				echo "<tr ><td style='background:#009696; color:white;' ><strong>Total Installments :</strong></td><td style='background:#00C2C2; color:white;'><strong>".CURRENCY." ".$t_payment."</strong></td></tr>";
			echo"</table></div>";
			
				
		}
		catch(PDOException $e)
		{
		echo $sql . "<br>" . $e->getMessage();
		}
		$conn = null;
	}
	
// ****************************************************************
// THIS METHOD IS USED TO INSERT RECORD IN INTEREST TABLE IN DATABASE
	function insert_interest($sql)
	{	
		//echo $sql."<br>";	
		try 
		{
		$conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE."", DB_USER, DB_PASSWORD);    
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql1 = $sql;    
		$conn->exec($sql1);
		$last_id = $conn->lastInsertId();
		//echo "New record created successfully. Account Number is = ".$last_id;
		echo "
		<div class='alert alert-success alert-dismissable'>
		<a href='#' class='close' data-dismiss='alert' aria-label='close'>×</a>
		<strong>Success!</strong> New Interest Added successfully. Interest ID is = <span class='badge'>".$last_id."</span>
		</div>
			 ";
		}
		catch(PDOException $e)
		{
		echo $sql . "<br>" . $e->getMessage();
		}
		$conn = null;	
	}
	
// ****************************************************************
// THIS METHOD IS USED TO FETCH RECORD FROM INSTALLMENT TABLE IN DATABASE
	function view_interest($sql,$status)
	{
		//echo $sql;
		$sql1=$sql;
		try 
		{
		$conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE."", DB_USER, DB_PASSWORD);    
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		// $sql1 = "SELECT * FROM `interest_state` WHERE 1";
				
		$stmt = $conn->query($sql1);
		$stmt1 = $conn->query($sql1);
		$stmt->setFetchMode(PDO::FETCH_ASSOC);

		$col_name=array();
		
					$row = $stmt->fetch();
					reset($row);
						echo"<div class='table-responsive'>";
						echo "<table class='table table-striped table-bordered table-hover table-condensed'>";
						echo "<thead><tr>";			
					while(list($key, $val) = each($row) ) {
						
						$str=strtoupper($key);
						$str=str_replace("_"," ",$str);
						echo "<th>".$str."</th>";					
					
						$col_name[]=$key;
					}
					echo "<th>E</th>";
					echo "<th>D</th>";
					echo "<th>V</th>";
						echo "</tr>";
		// print_r($col_name);
			
			if($stmt1->rowCount() > 0)
			{
			
					while($row1 = $stmt1->fetch()) 
					{
						echo "<tr>";
						echo "<td>".$row1['interest_id']."</td>";
						echo "<td>".$row1['client_id']."</td>";
						echo "<td>".$row1['date']."</td>";
						echo "<td>".$row1['interest']."</td>";
						
						echo "<td><a href='edit_all.php?id=".$row1['interest_id']."&act=interest' data-toggle='tooltip' title='Edit'><span class='glyphicon glyphicon-edit'></span> </a></td>";
						echo "<td><a href='del_interest.php?id=".$row1['interest_id']."' data-toggle='tooltip' title='Delete' onclick=\"return confirm(' Sure!! you want to delete?');\" ><span class='glyphicon glyphicon-trash red'></span> </a></td>";
						// echo "<td><a href='del_interest.php?id=".$row1['client_id']."' class='change_status' data-toggle='tooltip' title='Delete' ><span class='glyphicon glyphicon-trash red'></span> </a></td>";
						echo "<td><a href='view_all.php?id=".$row1['interest_id']."&act=interest' data-toggle='tooltip' title='View'><span class='	glyphicon glyphicon-eye-open'></span> </a></td>";
						
						
						 
						echo "</tr>";
					}	
			}
			else
			{
				echo "<tr><td>No Record found</td></tr>";
			}
			
				echo "</table></div>";
			
				
		}
		catch(PDOException $e)
		{
		echo $sql . "<br>" . $e->getMessage();
		}
		$conn = null;
	}

// ****************************************************************
// THIS METHOD IS USED TO DELETE RECORD FROM ALL TABLES TABLE IN DATABASE
	function data_delete($sql)
	{
		
		try 
		{
		$conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE."", DB_USER, DB_PASSWORD);    
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		// echo $sql;
		$count=$conn->exec($sql);
		
		// echo $count." row deleted"	;
			if($count>=1)
			{
				// echo $count." row deleted"	;
				echo "<div class='error'><div class='alert alert-success alert-dismissable'><strong>Success!</strong> ".$count." record deleted Successfully</div></div>";
			}
			else
			{
				echo "<div class='error'><div class='alert alert-warning alert-dismissable'><strong>Warning!</strong> 0 record deleted </div></div>";
			}
			// if($conn->exec($sql)==true)
			// {
				// echo "true";
			// }
			// else{
				// echo "false";
			// }
		}
		catch(PDOException $e)
		{
		echo $sql . "<br>" . $e->getMessage();
		}
		$conn = null;
	}
	
	
	function view_ALL($sql)
	{

		$sql1=$sql;

		// echo $status; 
		
		try 
		{
		$conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE."", DB_USER, DB_PASSWORD);    
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		//$sql1 = "SELECT * FROM `payment_state` WHERE 1";
				
		$stmt = $conn->query($sql1);
		$stmt1 = $conn->query($sql1);
		$stmt->setFetchMode(PDO::FETCH_ASSOC);

		$col_name=array();
		
					$row = $stmt->fetch();
					reset($row);
						echo"<div class='table-responsive'>";
						echo "<button id='print'  type='button' class='btn btn-default pull-right'>     <span class='glyphicon glyphicon-print'></span> Print    </button><br><br><br>";
						echo "<table class='table table-striped table-bordered table-hover table-condensed'>";
						echo "<thead><tr>";
					echo "<th></th>";
					echo "<th></th>";
						echo "</tr>";
											
					while(list($key, $val) = each($row) ) {
						$str=strtoupper($key);
						$str=str_replace("_"," ",$str);
						echo "<tr>";
						echo "<td>".$str."</td><td>".$val."</td>";
						echo "</tr>";
					//$col_name[]=$key;
					}
					
					// echo "<th>E</th>";
					// echo "<th>D</th>";
					// echo "<th>V</th>";
					
					
						die();
		// print_r($col_name);
			
			$t_payment='0';
			// echo "status: ".$status."<br>";
			// echo check_status_id(8);
			// die();
			// if(check_status_id($row1['client_id'])==$status)
			// {
				
			// }
	/* 		
			while($row1 = $stmt1->fetch()) 
			{
				
				// if(check_status_id($row1['client_id'])==$status)
					//echo $row1['client_id'];
						// echo check_status_id($row1['client_id']);
						// die();
					
					// if(check_status_id($row1['client_id'])==$status OR $status=="All")
					if(check_status_id($row1['client_id'])==$status OR $status=="All")	
					{
						// echo $status;
						// echo check_status_id($row1['client_id']);
					echo "<tr>";
					echo "<td>".$row1['payment_id']."</td>";
					echo "<td>".$row1['client_id']."</td>";
					echo "<td>".$row1['date']."</td>";
					echo "<td> ".$row1['deposit']."</td>";
					$t_payment=$t_payment+$row1['deposit'];				
					echo "<td><a href='".$row1['client_id']."' data-toggle='tooltip' title='Edit'><span class='glyphicon glyphicon-edit'></span> </a></td>";
					echo "<td><a href='del_payment.php?id=".$row1['payment_id']."' data-toggle='tooltip' title='Delete' onclick=\"return confirm(' Sure!! you want to delete?');\" ><span class='glyphicon glyphicon-trash red'></span> </a></td>";
					echo "<td><a href='".$row1['client_id']."' data-toggle='tooltip' title='View'><span class='	glyphicon glyphicon-eye-open'></span> </a></td>";
					echo "</tr>";
					}
					else
					{}
			}
	 */		
			// echo "<tr ><td style='background:#009696; color:white;' ><strong>Total Payments :</strong></td><td style='background:#00C2C2; color:white;'><strong>".CURRENCY." ".$t_payment."</strong></td></tr>";
			// echo"</table></div>";
				
			
				
		}
		catch(PDOException $e)
		{
		echo $sql . "<br>" . $e->getMessage();
		}
		$conn = null;	
}

	
	// ****************************************************************
// THIS METHOD IS USED TO FETCH REPORT IN DATABASE
	function view_report1($sql)
	{
		$sql1=$sql;
		try 
		{
		$conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE."", DB_USER, DB_PASSWORD);    
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		//$sql1 = "SELECT * FROM `client` WHERE 1";
				
		$stmt = $conn->query($sql1);
		$stmt1 = $conn->query($sql1);
		$stmt->setFetchMode(PDO::FETCH_ASSOC);

		$col_name=array();
		
					$row = $stmt->fetch();
					reset($row);
						echo"<div class='table-responsive'>";
						echo "<table class='table table-striped table-bordered table-hover table-condensed'>";
						echo "<thead><tr>";			
					while(list($key, $val) = each($row) ) {
					
						$str=strtoupper($key);
						$str=str_replace("_"," ",$str);
						
						echo "<th>".$str."</th>";
						
						
						
					$col_name[]=$key;
					}
					echo "<th>E</th>";
					echo "<th>D</th>";
					echo "<th>V</th>";
						echo "</tr>";
		// print_r($col_name);
		
			
			
			
			while($row1 = $stmt1->fetch()) 
			{
				echo "<tr>";
				echo "<td>".$row1['client_id']."</td>";
				echo "<td>".$row1['name']."</td>";
				echo "<td>".$row1['p_amount']."</td>";
				echo "<td>".$row1['interest_rate']."</td>";
				echo "<td>".$row1['installment']."</td>";
				echo "<td>".$row1['period']."</td>";
				echo "<td>".$row1['filecharge']."</td>";
				echo "<td>".$row1['rule']."</td>";				
				
				// echo "<td>".get_rule_name($row1['rule_id'])."</td>";
				
				echo "<td>".$row1['start_month']."</td>";
				echo "<td>".$row1['total_payable']."</td>";
				echo "<td>".$row1['status']."</td>";
				echo "<td><a href='".$row1['client_id']."' data-toggle='tooltip' title='Edit'><span class='glyphicon glyphicon-edit'></span> </a></td>";
				echo "<td><a href='del_customer.php?id=".$row1['client_id']."' data-toggle='tooltip' title='Delete' onclick=\"return confirm(' Sure!! you want to delete?');\" ><span class='glyphicon glyphicon-trash red'></span> </a></td>";
				echo "<td><a href='view_all.php?id=".$row1['client_id']."&act=customer' data-toggle='tooltip' title='View'><span class='	glyphicon glyphicon-eye-open'></span> </a></td>";
				
				
				 
				echo "</tr>";
			}	
			
				
			echo "</table></div>";
				
		}
		catch(PDOException $e)
		{
		echo $sql . "<br>" . $e->getMessage();
		}
		$conn = null;
	}
	
	function view_report($sql)
	{
		
		// TOTAL_INTEREST_BY_CID(9);
		$sql1=$sql;
		try 
		{
		$conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE."", DB_USER, DB_PASSWORD);    
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		//$sql1 = "SELECT * FROM `client` WHERE 1";
				
		$stmt = $conn->query($sql1);
		$stmt1 = $conn->query($sql1);
		$stmt->setFetchMode(PDO::FETCH_ASSOC);

		$col_name=array();
		
					
						echo"<div class='table-responsive'>";
						echo "<table class='table table-striped table-bordered table-hover table-condensed'>";
						echo "<thead><tr>";
						echo "</tr>";						
					
			
			if ($stmt->rowCount() > 0)
			{}else
{
				die ("0 record found");
			}
			
			$interest_rate=0;
			$filecharge=0;
			$interest=0;
			$p_amount=0;
			
			while($row1 = $stmt1->fetch()) 
			{
				$interest_rate=$row1['interest_rate'];
				$filecharge=$row1['filecharge'];
				echo "<tr>";
				echo "<td>Customer ID</td>";
				echo "<td>".$row1['client_id']."</td>";
				echo "</tr>";
				
				echo "<tr>";
				echo "<td>Customer Name</td>";
				echo "<td>".$row1['name']."</td>";
				echo "</tr>";
				
				echo "<tr>";
				echo "<td>Account Type</td>";
				echo "<td>".$row1['rule']."</td>";
				echo "</tr>";
				
				echo "<tr>";
				echo "<td>Opening Date</td>";
				echo "<td>".$row1['start_month']."</td>";
				echo "</tr>";
				
				echo "<tr>";
				echo "<td>Duration</td>";
				echo "<td>".$row1['period']." Months</td>";
				echo "</tr>";
				
				$p_amount=$row1['p_amount'];
				
				echo "<tr>";
				echo "<td>Total Principle to collect</td>";
				echo "<td>".$p_amount." Rs.</td>";
				// echo "<td>".$p_amount+$interest."=".$p_amount."=".$interest." Rs.</td>";
				echo "</tr>";				

				
				$interest=TOTAL_INTEREST_BY_CID($row1['client_id']);
				echo "<tr>";
				echo "<td>Total Interest to collect</td>";
				echo "<td>".$interest." Rs.</td>";
				echo "</tr>";
				
				// Total Payable including file charge
					$t_payable=$p_amount+$interest+$filecharge;
				// Total Payable without file charge to calculate monthly interest
				
					// $t_payable1=$p_amount+$interest;
					
					// $monthly_interest=($t_payable1/100)*$interest_rate;
					
								
				
				echo "<tr>";
				echo "<td>Total to collect=Principle+Interest+File Charge</td>";
				echo "<td>".$t_payable." Rs. = $p_amount(Principle) + $interest(Interest) +$filecharge(File Charge)</td>";
				echo "</tr>";
				
				$deposit=TOTAL_PAYMENT_BY_CID($row1['client_id']);
				echo "<tr>";
				echo "<td>Payment Received</td>";
				echo "<td>".$deposit." Rs.</td>";
				echo "</tr><tr>";
				
				$balance=$t_payable-$deposit;
				echo "<tr>";
				echo "<td>Total Balance</td>";
				echo "<td>".$balance." Rs.</td>";
				echo "</tr>";
				
				// echo "<tr>";
				// echo "<td>Monthly Interest</td>";
				// echo "<td>".$monthly_interest." Rs.</td>";
				// echo "</tr>";
				
				
				
			}
				
			echo "</table></div>";
				
		}
		catch(PDOException $e)
		{
		echo $sql . "<br>" . $e->getMessage();
		}
		$conn = null;
	}

	
		function update_dynamic($sql)
	{			
		
		try 
		{
		$conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE."", DB_USER, DB_PASSWORD);    
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);  
		$conn->exec($sql);
		$last_id = $conn->lastInsertId();
		
		echo "
		<div class='alert alert-success alert-dismissable'>
		<a href='#' class='close' data-dismiss='alert' aria-label='close'>×</a>
		<strong>Success!</strong> New Customer Added successfully. Account Number is = <span class='badge'>".$last_id."</span>
		</div>
			 ";
		}
		catch(PDOException $e)
		{
		echo $sql . "<br>" . $e->getMessage();
		}
		$conn = null;	
	}
 
// ****************************************************************
// THIS METHOD IS USED TO FETCH RECORD FROM Funds TABLE IN DATABASE 		  
  	function view_funds($sql)
	{
		$sql1=$sql;
		try 
		{
		$conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE."", DB_USER, DB_PASSWORD);    
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		//$sql1 = "SELECT * FROM `client` WHERE 1";
				
		$stmt = $conn->query($sql1);
		$stmt1 = $conn->query($sql1);
		$stmt->setFetchMode(PDO::FETCH_ASSOC);

		$col_name=array();
		
					$row = $stmt->fetch();
					reset($row);
						echo"<div class='table-responsive'>";
						echo "<table class='table table-striped table-bordered table-hover table-condensed'>";
						echo "<thead><tr>";			
					while(list($key, $val) = each($row) ) {
					
						$str=strtoupper($key);
						$str=str_replace("_"," ",$str);
						
						echo "<th>".$str."</th>";
						
						
						
					$col_name[]=$key;
					}
					echo "<th>E</th>";
					echo "<th>D</th>";
					echo "<th>V</th>";
						echo "</tr>";
		// print_r($col_name);
		
			$a_payment=0;
			$w_payment=0;
			$t_payment=0;
			$fund_type='';
			
			while($row1 = $stmt1->fetch()) 
			{
				echo "<tr>";
				echo "<td>".$row1['funds_id']."</td>";
				echo "<td>".$row1['amount']."</td>";
				echo "<td>".$row1['fund_type']."</td>";
				
				// echo $fund_type;
				if($row1['fund_type']=='Add')
				{
				$a_payment=$a_payment+$row1['amount'];
				}
				else if($row1['fund_type']=='Withdraw')
				{
				$w_payment=$w_payment+$row1['amount'];
				}
				
				
				
				echo "<td>".$row1['date']."</td>";
				echo "<td>".$row1['remarks']."</td>";
				
				echo "<td><a href='edit_all.php?id=".$row1['funds_id']."&act=funds' data-toggle='tooltip' title='Edit'><span class='glyphicon glyphicon-edit'></span> </a></td>";
				echo "<td><a href='del_funds.php?id=".$row1['funds_id']."' data-toggle='tooltip' title='Delete' onclick=\"return confirm(' Sure!! you want to delete?');\" ><span class='glyphicon glyphicon-trash red'></span> </a></td>";
				echo "<td><a href='view_all.php?id=".$row1['funds_id']."&act=funds' data-toggle='tooltip' title='View'><span class='	glyphicon glyphicon-eye-open'></span> </a></td>";
				
				
				 
				echo "</tr>";
			}

			$t_payment=$a_payment-$w_payment;			
			echo "<div class='row'><div class='col-sm-2' style='margin-left:20px; padding:3px; background:#009696; color:white;'><strong> Total Added Funds:</strong></div>  <div class='col-sm-1' style=' padding:3px; background:green; color:white;'>".CURRENCY." {$a_payment}</div></div>";
			echo "<div class='row'><div class='col-sm-2' style='margin-left:20px; padding:3px; background:#009696; color:white;'><strong> Total Funds Withdraw:</strong></div>  <div class='col-sm-1' style=' padding:3px; background:pink; color:black;'>".CURRENCY." {$w_payment}</div></div>";
			echo "<div class='row'><div class='col-sm-2' style='margin-left:20px; padding:3px; background:#009696; color:white;'><strong> Total Available:</strong></div>  <div class='col-sm-1' style=' padding:3px; background:#00C2C2; color:white;'>".CURRENCY." {$t_payment}</div></div>";	
			echo "</table></div>";
				
		}
		catch(PDOException $e)
		{
		echo $sql . "<br>" . $e->getMessage();
		}
		$conn = null;
	}


// ****************************************************************
// THIS METHOD IS USED TO FETCH total of one column from FROM all TABLE IN DATABASE 		  

	function get_total_of_one_column($sql,$column)
	{	
	
		//echo $sql;
		$sql1=$sql;
		try 
		{
		$conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE."", DB_USER, DB_PASSWORD);    
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		// $sql1 = "SELECT * FROM `interest_state` WHERE 1";
				
		$stmt = $conn->query($sql1);
		$stmt1 = $conn->query($sql1);
		$stmt->setFetchMode(PDO::FETCH_ASSOC);

			$total=0;
			if($stmt1->rowCount() > 0)
			{
			
					while($row1 = $stmt1->fetch()) 
					{
						
						$total=$total+$row1[$column];
						
					}	
					return $total;
			}
			else
			{
				return $total;
			}
			
				
			
				
		}
		catch(PDOException $e)
		{
		echo $sql . "<br>" . $e->getMessage();
		}
		$conn = null;
	}
	
?>