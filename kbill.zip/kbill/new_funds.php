<?php 
include 'header.php';
include 'include/function.php';


//print_r($_POST);

 // reset($_POST);
 // while (list($key, $val) = each($_POST)) {
     // echo "$key => $val\n";
	 // echo "$key \n";
 // }


if(isset($_POST['addfunds']))
{
	// print_r($_POST);
	
	 // reset($_POST);
 // while (list($key, $val) = each($_POST)) {
     // echo "$key => $val\n";
	 // echo "$key \n";
 // }
 
 
 
	$amount=$_POST['amount'];
	$fund_type=$_POST['fund_type'];
	$date=$_POST['date'];
	$remarks=$_POST['Remarks'];
	
		
	
	
	//INSERT INTO `payment_state`(`client_id`, `date`, `deposit`) VALUES ('$client_id', '$p_date', '$t_pay')
	// $sql="INSERT INTO `payment_state`(`client_id`, `date`, `deposit`) VALUES ('$client_id', '$p_date', '$t_pay')";
	$sql="INSERT INTO `funds`(`amount`, `fund_type`, `date`, `remarks`) VALUES ('$amount', '$fund_type', '$date', '$remarks')";
	// echo $sql;
	 insert_payment($sql);
}

?>

  <div id="new_customer" class="container-fluid">
  
  <div class="panel panel-default">
	  <div class="panel-heading"><strong>New Payment Entry</strong><p>This is New Payment Entry form</p></div>
			<div class="panel-body">
  <form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post">

  <div class="input-group">
      <span class="input-group-addon">Amount</span>
      <input id="amount1" name="amount" type="text" class="form-control"   required >
  </div>
  <br>
 <div class="input-group">
      <span class="input-group-addon">Type</span>
        <select id="fund_type" name="fund_type" class="form-control" >
		<option value="Add">Add</option>
		<option Value="Withdraw">Withdraw</option>
		</select>
		
  </div>
  <br>
  <div class="input-group">
      <span class="input-group-addon">Date</span>
      <input id="t_pay" name="date" type="date" class="form-control"    required >
  </div>
  <br>
  <div class="input-group">
      <span class="input-group-addon">Remarks</span>
      <input id="t_pay" name="Remarks" type="text" class="form-control"    required >
  </div>
  <br>
  
  
  <br>
  <button type="submit" name="addfunds" class="btn btn-primary">Submit</button>
</form>
	</div>
	<div class="panel-footer"></div>
	</div>
  </div>


  
	
	
	<br>
  <a href="#" class="btn btn-default btn-sm">
	<span class="glyphicon glyphicon-arrow-up"></span> Up
  </a>
  <br>

  
  <script>
  function calc(){
	  var file_charge=0;
      var p_amount = document.getElementById('p_amount').value;
      var i_rate = document.getElementById('i_rate').value;
	  var flex_or_fix = type.value;
	  var file_charge = document.getElementById('f_charge').value;
	  
	  var period = document.getElementById('Period').value;
	  
	  
	  // var p_amount =5;
      // var i_rate = 5;
	  
	  // var period = 5;
	  
	  //var t_pay = (p_amount/100)*i_rate;
	  
	  
	  var t_pay = (p_amount/100)*i_rate;
	  
	  var t_pay = parseInt((t_pay*period));
	  
	  //IF not FLEXI THEN ADD UP ALL INTEREST FOR WHOLE PERIOD
	  if(flex_or_fix==1)
	  {
	  var t_pay = parseInt(t_pay)+parseInt(p_amount);
	  }
	  else
	  {
		  var t_pay=parseInt(p_amount);
	  }
	  
	  var t_pay = parseInt(file_charge)+parseInt(t_pay);
	  //alert(flex_or_fix);
	  
	  document.getElementById("t_pay").value = t_pay;
	  
	  document.getElementById("M_instal").value = t_pay/period;
	  
      //alert(user.value);
      //alert(pass.value);
  }
</script>



<?php

include 'footer.php';
?>