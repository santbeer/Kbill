<?php 
include 'header.php';
include 'include/function.php';

$status='All';
$sql='0';
echo"<nav class='navbar navbar-default' >
			  <div class='container-fluid'>
			  <form class='navbar-form navbar-right' action='' method='post'>
			 
			 
			 	<div class='form-group' data-toggle='tooltip' title='Search by client status and payment status' ><div style='background:#00b3b3; padding:5px; border-radius:5px 5px 5px 5px; '>
				<select name='status1' class='form-control' id='sel1'>
				<option value='All'>All</option>
				<option value='Active'>Active</option>
				<option value='Closed'>Closed</option>
				</select >
				
				
				<select name='status2' class='form-control' id='sel1'>
				<option value='All'>All</option>
				<option value='Paid'>Paid</option>
				<option value='Pending'>Pending</option>
				</select >
				
				<button type='submit' name='show_all'  class='btn btn-default'><span class='glyphicon glyphicon-search'>  </button>
			  </div></div>
			  
			  			  
			  <div class='form-group' data-toggle='tooltip' title='Installment ID' ><div style='background:#00b3b3; padding:5px; border-radius:5px 5px 5px 5px; '>
				<input type='text' name='installment_id' class='form-control' placeholder='Installment ID'>
				<button type='submit' name='by_installment_id'  class='btn btn-default'><span class='glyphicon glyphicon-search'>  </button>
			  </div></div>

			  
			  <div class='form-group' data-toggle='tooltip' title='Search by ID'><div style='background:#00b3b3; padding:5px; border-radius:5px 5px 5px 5px; '>
				<input type='text' name='client_id' class='form-control' placeholder='Search Customer ID'>
				<button type='submit' name='by_customer_id'  class='btn btn-default'><span class='glyphicon glyphicon-search'>  </button>
			  </div></div>
			  
			  
			  
			  
			</form>
			  
			  </div>
			  </nav>";

							
							if(isset($_POST['by_customer_id']))
							{
								if($_POST['client_id']==null)
								{
									die("<div class='error'><div class='alert alert-warning alert-dismissable'><strong>Warning!</strong> Must enter valid customer id </div></div>");
								}
								$sql="SELECT * FROM `interest_state` WHERE `client_id`='".$_POST['client_id']."'";
							}
							else if(isset($_POST['by_installment_id']))
							{
								if($_POST['installment_id']==null)
								{
									die("<div class='error'><div class='alert alert-warning alert-dismissable'><strong>Warning!</strong> Must enter valid Installment id </div></div>");
								}
								$sql="SELECT * FROM `installment_state` WHERE `Installment_id`='".$_POST['installment_id']."'";
							}
							else if(isset($_POST['show_all']))
							{
								$status=$_POST['status1'];
								
								if($_POST['status2']=="Paid" or $_POST['status2']=="Pending" )
								{
									$sql="SELECT * FROM `installment_state` WHERE `status`='".$_POST['status2']."'";
								}
								else
								{
									// $sql="SELECT * FROM `interest_state` WHERE 1";
								}
								
							}
							else
							{
								$sql="SELECT * FROM `interest_state` WHERE 1";
							}
							
							
							

echo "<div class='panel panel-default'>
	  <div class='panel-heading'><strong>Interests List</strong></div>
			<div class='panel-body'>";
	// echo $sql;
// die();	
view_interest($sql,$status);

echo "</div></div>";


?>

<?php

include 'footer.php';
?>

