<script>
$(document).ready(function(){
    
        $(".error").fadeOut();
    
    
});
</script>