</div>
	<div>
	<nav class="navbar navbar-hydra" >
	  <div class="container-fluid">
		
		<ul class="nav navbar-nav">
      <li class="active"> <a href="#" >
      <span class="glyphicon glyphicon-home"></span> Home 
    </a></li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Manage Customers
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="new_customer.php">Add New Customer</a></li>
          <li><a href="view_customer.php">View/Edit Customer</a></li>
          
        </ul>
      </li>
	  <li><a class="dropdown-toggle" data-toggle="dropdown" href="#">Manage Payments
				<span class="caret"></span></a>
				<ul class="dropdown-menu">
				<li><a href="new_payment.php">Enter Payments</a></li>
				<li><a href="view_payment.php">View/Edit Payments</a></li>
          
				</ul>
			
	   </li>
	   
	   <li><a class="dropdown-toggle" data-toggle="dropdown" href="#">Manage Installments
				<span class="caret"></span></a>
				<ul class="dropdown-menu">
				<li><a href="new_installment.php">Enter Installment</a></li>
				<li><a href="view_installment.php">View/Edit Installment</a></li>          
				</ul>			
	   </li>
	   
	    <li><a class="dropdown-toggle" data-toggle="dropdown" href="#">Manage Interest
				<span class="caret"></span></a>
				<ul class="dropdown-menu">
				<li><a href="new_interest.php">Enter Interest</a></li>
				<li><a href="view_interest.php">View/Edit Interest</a></li>          
				</ul>			
	   </li>
	   
	   
		
	   <li><a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-cog"></span> Report
				<span class="caret"></span></a>
				<ul class="dropdown-menu">
				<li> <a href="view_report.php">Customer Report</a></li>
				<li><a href="view_funds.php">Company Funds Report</a></li>
				<li><a href="new_funds.php">Add/withdraw Funds</a></li>	
				<li><a href="view_overall_funds.php">Overall Funds Report</a></li>					
				</ul>			
	   </li>
	  
		
		
		<li> 
		<a href="#" class="btn btn-info1 btn-sm"><span class="glyphicon glyphicon-question-sign"></span> Help 
		</a>
		</li>
    </ul>
	
	<ul class="nav navbar-nav navbar-right">
      <li><a href=""><span class="glyphicon glyphicon-user"></span> <?php SESSION_CHECK(); ?></a></li>
      <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
    </ul>
		
		
	
	  </div>
	</nav>
	</div>