<div class = "page-header">
   
   <h1>
      <a href="#"><img class="brand" src="<?php echo LOGO_URL; ?>" width="150"></a> 
	  <!--Company Logo-->
      <small><!--Subtext for header--></small>
   </h1>