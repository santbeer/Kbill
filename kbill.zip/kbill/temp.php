<?php 
include 'header.php';
include 'include/function.php';


							
							
							
							
	
			
			echo TOTAL_INTEREST_BY_CID(1);



?>

<?php

include 'footer.php';
?>

