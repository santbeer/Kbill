<?php 
include 'header.php';
include 'include/function.php';

			echo"<nav class='navbar navbar-default' >
				<div class='container-fluid'>
			<form class='navbar-form navbar-right' action='' method='post'>
				
			 
			 
			  

				<div class='form-group'><div style='background:#00b3b3; padding:5px; border-radius:5px 5px 5px 5px; '>
				<input type='text' name='client_id' class='form-control' placeholder='Customer ID'>
				<button type='submit' name='search1' data-toggle='tooltip' title='Search by Customer ID' class='btn btn-default'><span class='glyphicon glyphicon-search'> Search</button>
				</div></div>
			  
			</form>
			  
				</div>
				</nav>";

							
							
							
				
	//echo $sql;
	// $sql='SELECT * FROM `client` WHERE 1';
	
			echo "<div class='panel panel-default'>
			<div class='panel-heading'><strong>Customer Report</strong></div>
			
			<div class='panel-body'>";
		
							if(isset($_POST['search1']))	
							{
								echo "<button id='print'  type='button' class='btn btn-default pull-right'>     <span class='glyphicon glyphicon-print'></span> Print    </button><br><br><br>";
								$sql="SELECT * FROM `client` WHERE `client_id`='".$_POST['client_id']."'";
								view_report($sql);
							}
							else{
								// $sql="SELECT * FROM `client` WHERE 1";
							}	


echo "</div></div>";

?>

<?php

include 'footer.php';
?>

