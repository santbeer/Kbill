<!DOCTYPE html>
<html lang="en">
<head>
  <title>Finance Management Suite</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link href="https://fonts.googleapis.com/css?family=Droid+Sans" rel="stylesheet">
  <link rel="stylesheet" href="css/custom.css">
  <script src="js/jquery.js"></script>
  
  <style>
  body
  {
	font-family: 'Droid Sans', sans-serif; 
	
	
  }
  .brand
  {
	margin-left:3%;  
  }
  .red
  {
	  color:red;
	  
  }
  .green
  {
	  color:green;
  }
  
  
  tr:nth-child(even) {
    background-color: #EBEBEB;
	
}

tr {
   
	color:grey;
}

  
  </style>
 <script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();

 $("#print").click(function(){
    
        $("#print").hide();
        window.print();       
        $("#print").show();
    });

	
});


				function deleteItem()
				{
					var checkstr =  confirm('are you sure you want to delete this?');
					if(checkstr == true){
					  
					}
					else
					{
					return false;
					}
				  }

  
</script>

<script>
    $(document).ready(function() {
         $("a.change_status").click(function(){
           var status_id = $(this).attr('href').split('=');
            
			
												$( ".change_status" ).html("Are you sure you want to delete the record? ").dialog({
												  resizable: false,
												  height: "auto",
												  width: 600,
												  modal: true,
												  buttons: {
													"Delete": function() {
													  $( this ).dialog( "close" );
													  window.location.href = "?status="+status_id;
													},
													Cancel: function() {
													  $( this ).dialog( "close" );
													  return false;
													}
												  }
												});
           return false;
        });
    });
	
	
	$(document).ready(function() {
    $("#amount1").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
             // Allow: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) ||
             // Allow: Ctrl+C
            (e.keyCode == 67 && e.ctrlKey === true) ||
             // Allow: Ctrl+X
            (e.keyCode == 88 && e.ctrlKey === true) ||
             // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
});
  </script>



</head>
<body>

<?php include 'include/function1.php'; ?>
<?php 

// include 'include/session_check.php'; 
?>


<?php include "configuration.php"; ?>
<?php include "logo.php";?>
<?php include "navigation.php"; ?>

<?php //include "slider.php"; ?>
  