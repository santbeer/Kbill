<?php 
include 'header.php';
include 'include/function.php';

			echo"<nav class='navbar navbar-default' >
			  <div class='container-fluid'>
			  <form class='navbar-form navbar-right' action='' method='post'>
			 
			 
			  <div class='form-group'><div style='background:#00b3b3; padding:5px; border-radius:5px 5px 5px 5px; '>
				<select name='status' class='form-control' id='sel1'>
				<option value='All'>All</option>
				<option value='Active'>Active</option>
				<option value='Closed'>Closed</option>
				</select >
				<button type='submit' name='search' data-toggle='tooltip' title='Search' class='btn btn-default'><span class='glyphicon glyphicon-search'> Search</button>
			  </div></div>
			  

			  <div class='form-group'><div style='background:#00b3b3; padding:5px; border-radius:5px 5px 5px 5px; '>
				<input type='text' name='client_id' class='form-control' placeholder='Search By ID'>
				<button type='submit' name='search1' data-toggle='tooltip' title='Search by ID' class='btn btn-default'><span class='glyphicon glyphicon-search'> Search</button>
			  </div></div>
			  
			</form>
			  
			  </div>
			  </nav>";

							if(isset($_POST['search']))	
							{
								if($_POST['status']=='Active')
												{
													$sql="SELECT * FROM `client` WHERE `status`='".$_POST['status']."'";
												}
												else if($_POST['status']=='Closed')
												{
													$sql="SELECT * FROM `client` WHERE `status`='".$_POST['status']."'";
												}
												else if($_POST['status']=='All')
												{
													$sql='SELECT * FROM `client` WHERE 1';
												}
							}
							else if(isset($_POST['search1']))
							{
								$sql="SELECT * FROM `client` WHERE `client_id`='".$_POST['client_id']."'";
							}	
							else{
								$sql="SELECT * FROM `client` WHERE 1";
							}
				
	//echo $sql;
// $sql='SELECT * FROM `client` WHERE 1';
echo "<div class='panel panel-default'>
	  <div class='panel-heading'><strong>Customer List</strong></div>
			<div class='panel-body'>";
			
view_customer($sql);

echo "</div></div>";

?>

<?php

include 'footer.php';
?>

