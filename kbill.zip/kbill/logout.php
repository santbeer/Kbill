<?php 
include 'login_header.php';

session_start();
session_unset();
session_destroy(); 


?>
<div class="container">
  <h2>Logged out</h2>
  <div class="panel panel-danger">
    <div class="panel-heading"><strong>Warning:</strong> Your session is Expired</div>
    <div class="panel-body">You are not logged in.  <a href='login.php' >Click here</a> to login again.</div>
  </div>
</div>
<?php

include 'footer.php';
?>