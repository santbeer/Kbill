<?php 
include 'header.php';
include 'include/function.php';

$id=0;
	if($_GET['id']=='' or $_GET['id']==NULL or $_GET['act']=='' or $_GET['act']==NULL )
	{
		die("<div class='error'><div class='alert alert-warning alert-dismissable'><strong>Sorry!</strong> Could not process request with NULL parameter </div></div>");
	}
	else
	{
	$id=$_GET['id'];	
	}


						if($_GET['act']=='interest')
						{
						$sql="SELECT * FROM `interest_state` WHERE `interest_id`='$id'"	;
						view_ALL($sql);
						}
						else if($_GET['act']=='installment')
						{
						$sql="SELECT * FROM `installment_state` WHERE `Installment_id`='$id'"	;
						view_ALL($sql);
						}
						else if($_GET['act']=='payment')
						{
						$sql="SELECT * FROM `payment_state` WHERE `payment_id`='$id'"	;
						view_ALL($sql);	
						}
						else if($_GET['act']=='customer')
						{
						$sql="SELECT * FROM `client` WHERE `client_id`='$id'"	;
						view_ALL($sql);	
						}
						else
						{
							die("<div class='error'><div class='alert alert-warning alert-dismissable'><strong>Sorry!</strong> Unexpected Parameter Received </div></div>");
						}

?>

  
	


  
 



<?php

include 'footer.php';
?>