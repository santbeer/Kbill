<?php 
include 'header.php';
include 'include/function.php';


//print_r($_POST);

// reset($_POST);
// while (list($key, $val) = each($_POST)) {
    // echo "$key => $val\n";
	// echo "$key \n";
// }


if(isset($_POST['new_interest']))
{
	$client_id=$_POST['client_id'];
	$i_date=$_POST['i_date'];
	$Interest_amount=$_POST['Interest_amount'];		
	
	
	//INSERT INTO `interest_state`(`client_id`, `date`, `interest`) VALUES ('$client_id', '$i_date', '$Interest_amount')
	$sql="INSERT INTO `interest_state`(`client_id`, `date`, `interest`) VALUES ('$client_id', '$i_date', '$Interest_amount')";
	//echo $sql;
	 insert_interest($sql);
}

?>

  <div id="new_customer" class="container-fluid">
  
  <div class="panel panel-default">
	  <div class="panel-heading"><strong>New Interest Entry</strong><p>This is New Interest Entry form</p></div>
			<div class="panel-body">
  <form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post">
  <div class="input-group">
      <span class="input-group-addon">Client ID/Account Number</span>
      <input id="c_name" name="client_id" type="text" class="form-control"   required >
  </div>
  <br>
  <div class="input-group">
      <span class="input-group-addon">Interest Date</span>
      <input id="s_date" name="i_date" type="date" class="form-control"    required >
  </div>
  <br>
  <div class="input-group">
      <span class="input-group-addon">Interest Amount</span>
      <input id="t_pay" name="Interest_amount" type="text" class="form-control"    required >
  </div>
  <br>
  
  <button type="submit" name="new_interest" class="btn btn-primary">Submit</button>
</form>
	</div>
	<div class="panel-footer"></div>
	</div>
  </div>


  
	
	
	<br>
  <a href="#" class="btn btn-default btn-sm">
	<span class="glyphicon glyphicon-arrow-up"></span> Up
  </a>
  <br>

  
 



<?php

include 'footer.php';
?>