<?php 
include 'header.php';
include 'include/function.php';


//print_r($_POST);

 // reset($_POST);
 // while (list($key, $val) = each($_POST)) {
     // echo "$key => $val\n";
	 // echo "$key \n";
 // }


if(isset($_POST['new_payment']))
{
	$client_id=$_POST['client_id'];
	$p_date=$_POST['p_date'];
	$t_pay=$_POST['t_pay'];
	$form_t=$_POST['form_t'];
	$new_payment=$_POST['new_payment'];
	// $client_id=$_POST['client_id'];
	// $p_date=$_POST['p_date'];
	// $t_pay=$_POST['t_pay'];
	// $M_instal=$_POST['M_instal'];
	// $status=$_POST['status'];
	// $form_t=$_POST['form_t'];
	// $new_payment=$_POST['new_payment'];
		
	
	
	//INSERT INTO `payment_state`(`client_id`, `date`, `deposit`) VALUES ('$client_id', '$p_date', '$t_pay')
	$sql="INSERT INTO `payment_state`(`client_id`, `date`, `deposit`) VALUES ('$client_id', '$p_date', '$t_pay')";
	//echo $sql;
	 insert_payment($sql);
}

?>

  <div id="new_customer" class="container-fluid">
  
  <div class="panel panel-default">
	  <div class="panel-heading"><strong>New Payment Entry</strong><p>This is New Payment Entry form</p></div>
			<div class="panel-body">
  <form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post">

  <div class="input-group">
      <span class="input-group-addon">Client ID/Account Number</span>
      <input id="c_name" name="client_id" type="text" class="form-control"   required >
  </div>
  <br>
  <div class="input-group">
      <span class="input-group-addon">Payment Date</span>
      <input id="s_date" name="p_date" type="date" class="form-control"    required >
  </div>
  <br>
  <div class="input-group">
      <span class="input-group-addon">Deposit</span>
      <input id="t_pay" name="t_pay" type="text" class="form-control"    required >
  </div>
  <br>
  <input id="t_pay" name="form_t" type="hidden" class="form-control" value="new_payment"    required >
  
  <br>
  <button type="submit" name="new_payment" class="btn btn-primary">Submit</button>
</form>
	</div>
	<div class="panel-footer"></div>
	</div>
  </div>


  
	
	
	<br>
  <a href="#" class="btn btn-default btn-sm">
	<span class="glyphicon glyphicon-arrow-up"></span> Up
  </a>
  <br>

  
  <script>
  function calc(){
	  var file_charge=0;
      var p_amount = document.getElementById('p_amount').value;
      var i_rate = document.getElementById('i_rate').value;
	  var flex_or_fix = type.value;
	  var file_charge = document.getElementById('f_charge').value;
	  
	  var period = document.getElementById('Period').value;
	  
	  
	  // var p_amount =5;
      // var i_rate = 5;
	  
	  // var period = 5;
	  
	  //var t_pay = (p_amount/100)*i_rate;
	  
	  
	  var t_pay = (p_amount/100)*i_rate;
	  
	  var t_pay = parseInt((t_pay*period));
	  
	  //IF not FLEXI THEN ADD UP ALL INTEREST FOR WHOLE PERIOD
	  if(flex_or_fix==1)
	  {
	  var t_pay = parseInt(t_pay)+parseInt(p_amount);
	  }
	  else
	  {
		  var t_pay=parseInt(p_amount);
	  }
	  
	  var t_pay = parseInt(file_charge)+parseInt(t_pay);
	  //alert(flex_or_fix);
	  
	  document.getElementById("t_pay").value = t_pay;
	  
	  document.getElementById("M_instal").value = t_pay/period;
	  
      //alert(user.value);
      //alert(pass.value);
  }
</script>



<?php

include 'footer.php';
?>