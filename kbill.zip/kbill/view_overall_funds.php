<?php 
include 'header.php';
include 'include/function.php';

			echo"<nav class='navbar navbar-default' >
			  <div class='container-fluid'>
			  <form class='navbar-form navbar-right' action='' method='post'>
			 
			 
			  <div class='form-group'><div style='background:#00b3b3; padding:5px; border-radius:5px 5px 5px 5px; '>
				<select name='status' class='form-control' id='sel1'>
				<option value='All'>All</option>
				<option value='Active'>Active</option>
				<option value='Closed'>Closed</option>
				</select >
				<button type='submit' name='search' data-toggle='tooltip' title='Search' class='btn btn-default'><span class='glyphicon glyphicon-search'> Search</button>
			  </div></div>
			  

			  <div class='form-group'><div style='background:#00b3b3; padding:5px; border-radius:5px 5px 5px 5px; '>
				<input type='text' name='client_id' class='form-control' placeholder='Search By ID'>
				<button type='submit' name='search1' data-toggle='tooltip' title='Search by ID' class='btn btn-default'><span class='glyphicon glyphicon-search'> Search</button>
			  </div></div>
			  
			</form>
			  
			  </div>
			  </nav>";

							if(isset($_POST['search']))	
							{}	
							else{
								$sql_installment="SELECT `installment` FROM `installment_state` WHERE 1";
								$sql_installment_column="installment";
								$sql_payment="SELECT `deposit` FROM `payment_state` WHERE 1";
								$sql_payment_column="deposit";
								$sql_funds_add="SELECT `amount` FROM `funds` WHERE `fund_type`='Add'";
								$sql_funds_add_column="amount";
								$sql_funds_withdraw="SELECT `amount` FROM `funds` WHERE `fund_type`='Withdraw'";
								$sql_funds_withdraw_column="amount";
							}
				
			//echo $sql;
			// $sql='SELECT * FROM `client` WHERE 1';
			echo "<div class='panel panel-default'>
	  <div class='panel-heading'><strong>Company Funds Record</strong></div>
			<div class='panel-body'>";
			
			// echo $sql_installment;
		// echo get_total_of_one_column($sql_installment,$sql_installment_column)."<br>";
		// echo get_total_of_one_column($sql_payment,$sql_payment_column);
		
		$pending_payment=get_total_of_one_column($sql_installment,$sql_installment_column)-get_total_of_one_column($sql_payment,$sql_payment_column);
		echo "Payment to collect=".$pending_payment;

//Pending Installments
echo "</div></div>";

?>

<?php

include 'footer.php';
?>

