<?php

// define ('DB_USER', "eclasc7u_bhupesh");
// define ('DB_PASSWORD', "9467620136");
// define ('DB_DATABASE', "eclasc7u_bhupesh");
// define ('DB_HOST', "nzis.in");


define ('DB_USER', "root");
define ('DB_PASSWORD', "");
define ('DB_DATABASE', "financeo");
define ('DB_HOST', "localhost");



define ('website', "localhost");
define ('COMPANY', "Bhupesh Chander");
define ('DEVELOPER_NAME', "STL IT SERVICE");
define ('DEVELOPER_LINK', "http://stlitservice.com/");
define ('LOGO_URL', "images/logo.png");
define ('CURRENCY', "Rs. ");



?>