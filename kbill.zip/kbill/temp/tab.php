<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Case</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Dynamic Tabs</h2>
  <p>To make the tabs toggleable, add the data-toggle="tab" attribute to each link. Then add a .tab-pane class with a unique ID for every tab and wrap them inside a div element with class .tab-content.</p>

  <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#home">Search By status</a></li>
    <li><a data-toggle="tab" href="#menu1">Date Range</a></li>
    <li><a data-toggle="tab" href="#menu2">Payment ID</a></li>
    <li><a data-toggle="tab" href="#menu3">Customer ID</a></li>
  </ul>

  <div class="tab-content">
 <form class='navbar-form navbar-right' action='' method='post'>
 
    <div id="home" class="tab-pane fade in active">
      <h4>Search By Status</h4>
      <div class='form-group'><div style='background:#00b3b3; padding:5px; border-radius:5px 5px 5px 5px; '>
				<select name='status' class='form-control' id='sel1'>
				<option value='All'>All</option>
				<option value='Active'>Active</option>
				<option value='Closed'>Closed</option>
				</select >
				<button type='submit' name='show' data-toggle='tooltip' title='Search' class='btn btn-default'><span class='glyphicon glyphicon-search'> Search</button>
			  </div></div>
    </div>
	
    <div id="menu1" class="tab-pane fade">
      <h4>Search in Date Range</h4>
      <div data-toggle='tooltip' title='Enter Starting Date and Ending Date' class='form-group'><div style='background:#00b3b3; padding:5px; border-radius:5px 5px 5px 5px; '>
				<input type='date'  name='date_from' class='form-control'>
				<input type='date' name='date_to' class='form-control'>
				<button type='submit' name='by_date_range' class='btn btn-default'><span class='glyphicon glyphicon-search'> Search</button>
			  </div></div>
    </div>
	
	
    <div id="menu2" class="tab-pane fade">
      <h4>Payment ID</h4>
      <div class='form-group'><div style='background:#00b3b3; padding:5px; border-radius:5px 5px 5px 5px; '>
				<input type='text' name='Payment_id' class='form-control' placeholder='Payment ID'>
				<button type='submit' name='by_payment_id' data-toggle='tooltip' title='Transaction ID' class='btn btn-default'><span class='glyphicon glyphicon-search'> Search</button>
			  </div></div>
    </div>
	
    <div id="menu3" class="tab-pane fade">
      <h4>Customer ID</h4>
	  <div class='form-group'><div style='background:#00b3b3; padding:5px; border-radius:5px 5px 5px 5px; '>
				<input type='text' name='client_id' class='form-control' placeholder='Search Customer ID'>
				<button type='submit' name='by_customer_id' data-toggle='tooltip' title='Search by ID' class='btn btn-default'><span class='glyphicon glyphicon-search'> Search</button>
			  </div></div>
	  </div>
	
	</form>
  </div>
</div>

</body>
</html>
